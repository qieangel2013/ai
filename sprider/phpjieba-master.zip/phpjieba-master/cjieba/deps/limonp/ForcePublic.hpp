#ifndef LIMONP_FORCE_PUBLIC_H
#define LIMONP_FORCE_PUBLIC_H

#define private public
#define protected public

#endif // LIMONP_FORCE_PUBLIC_H
